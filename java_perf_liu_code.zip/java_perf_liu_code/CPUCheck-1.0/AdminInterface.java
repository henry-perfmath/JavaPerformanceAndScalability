import java.rmi.*;

public interface AdminInterface extends Remote {
	void processCommand(String command) throws RemoteException;
	void processCommand(String[] commands) throws RemoteException;
}

