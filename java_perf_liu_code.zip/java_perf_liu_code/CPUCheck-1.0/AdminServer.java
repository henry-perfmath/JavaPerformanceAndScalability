import java.rmi.*;
import java.rmi.registry.*;
import java.io.Console;
import java.net.*;
import javax.swing.*;
import java.util.*;

public class AdminServer extends java.rmi.server.UnicastRemoteObject implements
		AdminInterface {
	int port;
	String uri;
	Registry registry; 
	static AdminConsole adminConsole = null;
	public void processCommand(String[] commandBuffer) throws RemoteException {
		for (String command: commandBuffer) {
			if (command.contains(" ")) processCommand (command);
		}
	}
	public void processCommand(String command) throws RemoteException {
		StringTokenizer st = new StringTokenizer (command, " ");
		String commandName = st.nextToken();
		if (commandName.equals("addNode")) { // top siblings
			String nodeName = st.nextToken();
			adminConsole.addNode (nodeName);
		} else if (commandName.equals("addContainer")) { 
			String containerName = st.nextToken();
			String containeeName = st.nextToken();
			adminConsole.addContainer (containerName, containeeName);
		} else if (commandName.equals("addContainee")) { 
			String containerName = st.nextToken();
			String containeeName = st.nextToken();
			adminConsole.addContainee (containerName, containeeName);
		} else if  (commandName.equals("addEntry")) { // leaf
			String leafNodeName = st.nextToken();
			String entryName = st.nextToken();
			adminConsole.addEntryToLeafNode(leafNodeName, entryName);
		} else if  (commandName.equals("removeNode")) {
			String nodeName = st.nextToken();
			adminConsole.removeNode(nodeName);
		} else if  (commandName.equals("removeAll")) { 
			adminConsole.removeAll ();
			adminConsole.reload(); // added 2/10/2009
		} else if  (commandName.equals("getLeafNodeEntryCount")) { 
			String path = st.nextToken();
			System.out.println (adminConsole.getLeafNodeEntryCount (path));
		} else if  (commandName.equals("reload")) { 
			adminConsole.checkMemory ("before reload:");
			adminConsole.reload();
			adminConsole.checkMemory ("after reload:");
		} else if (commandName.equals("checkMemory")) { 
			adminConsole.checkMemory ("admin server:");
		} else {
			if (command.length() > 1) { // allow empty command
				System.out.println ("command " + command + " with command name " +
					commandName + " is invalid");
			}
		}
		//adminConsole.reload(); // call reload for each cmd to get UI updated
		// 2/10/2009: this causes AWT exceptions for a large service tree
	}
	
	public AdminServer() throws RemoteException {
		try {
			uri = (InetAddress.getLocalHost()).toString();
		} catch (Exception e) {
			throw new RemoteException("can't get inet address.");
		}
		port = 9999;
		//uri = "127.0.0.1";
		System.out.println("uri =" + uri + " , port=" + port);
		try {
			registry = LocateRegistry.createRegistry(port);
			registry.rebind("AdminServer", this);
		} catch (RemoteException e) {
			throw e;
		}
		createAdminConsole ("Content");
	}

	static public void main(String args[]) {
		try {
			AdminServer s = new AdminServer();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	public static void createAdminConsole (String root) {
		  setLookAndFeel ();
	      adminConsole = new AdminConsole(root);
	      adminConsole.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      adminConsole.setVisible(true);		
	}
	public static void setLookAndFeel () {
		try {
	       // UIManager.setLookAndFeel(
	        //        UIManager.getCrossPlatformLookAndFeelClassName());
	        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	        
	    } 
	    catch (UnsupportedLookAndFeelException e) { }
	    catch (ClassNotFoundException e) { }
	    catch (InstantiationException e) { }
	    catch (IllegalAccessException e) { }

	}

}
