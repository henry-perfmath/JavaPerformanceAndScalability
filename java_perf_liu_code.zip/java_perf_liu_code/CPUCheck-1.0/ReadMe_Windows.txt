Before you run CPUCheck, please copy/rename java.exe from your JDK's bin directory to java-as.exe 
and java-sd.exe that will be needed by the runServer.bat and runClient.bat scripts.