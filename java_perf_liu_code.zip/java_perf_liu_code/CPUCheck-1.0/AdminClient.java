import java.rmi.*;
import java.rmi.registry.*;
import java.net.*;

public class AdminClient
{
    static public void main(String args[])
    {
       AdminInterface adminServer;
       Registry registry;
       String serverAddress = args[0];
       String serverPort = args[1];
       String command = args[2];
       //System.out.println("sending " + command + " to " 
       //	+ serverAddress + ":" + serverPort);
       try{
           registry=LocateRegistry.getRegistry(
               serverAddress,
               (new Integer(serverPort)).intValue()
           );
           adminServer=
              (AdminInterface)(registry.lookup("AdminServer"));
           
           adminServer.processCommand(command);
       }
       catch(RemoteException e){
           e.printStackTrace();
       }
       catch(NotBoundException e){
           e.printStackTrace();
       }
    }
}

 

