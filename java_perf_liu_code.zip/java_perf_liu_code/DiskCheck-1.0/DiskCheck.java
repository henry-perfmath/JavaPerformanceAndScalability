//usage: need a file in the same directory
//java -classpath . DiskCheck ioTest1.txt
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.Date;

public class DiskCheck {
	public static void main(String[] args) {
		String fileName = args[0];
		readWriteTest("./" + fileName);
	}

	public static void readWriteTest(String fileName) {
		BufferedReader reader = null;
		PrintWriter writer = null;
		long totalReadTime = 0;
		long totalWriteTime = 0;

		try {
			reader = new BufferedReader(new FileReader(fileName));
			String date = (new Date().toString()).replace(' ', '_');
			String writeFileName = "writeTest_" + date.replace(':', '_')
					+ ".txt";

			writer = new PrintWriter(new FileWriter(writeFileName), true);
		} catch (IOException ioe) {
			System.out.println(fileName + " not found");
		}

		String line = null;
		int count = 0;
		long startTime = System.currentTimeMillis();
		do {
			try {
				long time0 = System.currentTimeMillis();
				line = reader.readLine();
				long time1 = System.currentTimeMillis();
				totalReadTime = totalReadTime + (time1 - time0);
				time0 = System.currentTimeMillis();
				writer.println(line);
				time1 = System.currentTimeMillis();
				totalWriteTime = totalWriteTime + (time1 - time0);
				count++;

			} catch (IOException io) {
				System.out.println("Error reading or writing with " + fileName);
			}

		} while (line != null);
		long fileSize = (new File(fileName)).length();
		System.out.println("test data file size = "
				+ format(fileSize * 0.000001) + " MB");
		System.out.println("total time = "
				+ (System.currentTimeMillis() - startTime) / 1000 + " seconds");
		System.out.println("# of reads = # of writes = " + count);
		System.out.println("total read time (ms) = " + totalReadTime);
		System.out.println("average time (ms)/read = " + totalReadTime
				/ (float) count);
		System.out.println("total write time (ms) = " + totalWriteTime);
		System.out.println("average time (ms)/write = " + totalWriteTime
				/ (float) count);
		System.out.println("read is " + totalWriteTime / totalReadTime
				+ " times faster than write");
		System.out.println("Read throughput on this drive: "
				+ format(0.001 * fileSize / totalReadTime) + " MB/second");
		System.out.println("Write throughput on this drive: "
				+ format(0.001 * fileSize / totalWriteTime) + " MB/second");
	}

	public static double format(double d) {
		return ((new BigDecimal(d)).setScale(2, BigDecimal.ROUND_HALF_UP))
				.doubleValue();
	}
}
